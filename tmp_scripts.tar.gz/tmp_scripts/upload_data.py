from pathlib import Path
from datasets import Dataset
from lerobot.scripts.push_dataset_to_hub import push_meta_data_to_hub, push_videos_to_hub


def upload_data(data_dir, repo_id):
    hf_dataset = Dataset.load_from_disk(Path(f"{data_dir}/hf_data"))
    hf_dataset.push_to_hub(repo_id, token=True, revision="main")

    push_meta_data_to_hub(repo_id, f"{data_dir}/meta_data", revision="main")
    push_videos_to_hub(repo_id, f"{data_dir}/videos", revision="main")


if __name__ == "__main__":
    task = "three_piece_assembly"
    data_dir = f"converted/{task}"
    repo_id = f"kywch/mg_{task}"
    upload_data(data_dir, repo_id)
