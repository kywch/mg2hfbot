# read ep_success.json from the meta_data dir
import json

lerobot_data = "converted/mimicgen_stack_d1"

with open(f"{lerobot_data}/meta_data/ep_success.json", "r") as f:
    ep_success = json.load(f)

success = [v["is_success"] for v in ep_success.values()]
print(sum(success) / len(success))

# stack d0: 0.907
# stack d1: 0.852

