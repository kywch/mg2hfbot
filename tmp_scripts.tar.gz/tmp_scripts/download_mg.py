from mimicgen import DATASET_REGISTRY
from convert_mg_to_lerobot import download_mimicgen_dataset

download_dir = "mg_download"
data_type = "source"

for task in DATASET_REGISTRY[data_type]:
    download_mimicgen_dataset(download_dir, task, data_type)
