import json
import h5py
import yaml

import numpy as np

import robomimic.utils.env_utils as EnvUtils
import robomimic.utils.obs_utils as ObsUtils

mg_dir = "mg_download/source/"
mg_task = "hammer_cleanup"

mg_file = h5py.File(f"{mg_dir}/{mg_task}.hdf5", "r")

demos = list(mg_file["data"].keys())
env_meta = json.loads(mg_file["data"].attrs["env_args"])

img_height, img_width = 256, 256
env_meta["env_kwargs"]["camera_heights"] = img_height
env_meta["env_kwargs"]["camera_widths"] = img_width


env = EnvUtils.create_env_from_metadata(
    env_meta=env_meta,
    render=False,  # no on-screen rendering
    render_offscreen=True,  # off-screen rendering to support rendering video frames
    use_image_obs=True,
)

ObsUtils.initialize_obs_modality_mapping_from_dict(
    modality_mapping={"rgb": [f"{k}_image" for k in env_meta["env_kwargs"]["camera_names"]]}
)

obs = env.reset()

# state_keys = ["object", "robot0_joint_pos", "robot0_joint_vel", "robot0_eef_pos", "robot0_eef_quat",
#               "robot0_eef_vel_lin", "robot0_eef_vel_ang", "robot0_gripper_qpos", "robot0_gripper_qvel"]

# state_keys += ["robot0_eef_pos_rel_pod", "robot0_eef_quat_rel_pod",
#                "robot0_eef_pos_rel_pod_holder", "robot0_eef_quat_rel_pod_holder"]

state_keys = ["object"] + [k for k in obs.keys() if k.startswith("robot0") and "image" not in k]

state_obs_list = []
for k in state_keys:
    obs_array = np.array(obs[k])
    if obs_array.ndim == 0:
        obs_array = np.expand_dims(obs_array, axis=0)

    state_obs_list.append(obs_array)

state_dim = np.concatenate(state_obs_list).shape[0]
print("State dim:", state_dim)

demos = list(mg_file["data"].keys())

num_actions = []
for demo_key in demos:
    action_mat = mg_file[f"data/{demo_key}/actions"][:]
    num_actions.append(action_mat.shape[0])

print("Max num actions:", max(num_actions))

length = round(max(num_actions)/50 + 2) * 50
print("Set episode length to:", length)

assert env_meta["env_kwargs"]["camera_names"] == ["agentview", "robot0_eye_in_hand"]


env_config = {
    "fps": 20,
    "env": {
        "name": "mimicgen",
        "task": env_meta["env_name"],
        "state_dim": state_dim,
        "action_dim": 7,
        "episode_length": length,
        "meta": f"{mg_task}_env.json",
        "image_keys": ["agentview", "robot0_eye_in_hand"],
        "state_keys": state_keys,
    },
}

demo_key = demos[0]

init_state = mg_file[f"data/{demo_key}/states"][0]
model_xml = mg_file[f"data/{demo_key}"].attrs["model_file"]
initial_state_dict = dict(states=init_state, model=model_xml)
action_mat = mg_file[f"data/{demo_key}/actions"][:]

env.reset_to(initial_state_dict)


# save env config to configs/env
with open(f"configs/env/{mg_task}.yaml", "w") as f:
    yaml.dump(env_config, f, sort_keys=False)

# save env meta to env_meta
with open(f"env_meta/{mg_task}_env.json", "w") as f:
    json.dump(env_meta, f, indent=2)




print()